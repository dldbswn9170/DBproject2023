#pragma once
#include "adjList.h"

void DFS_adjList(graphType2* g, int v);
