void treeSort(int a[], int n);
