#pragma once
#include "adjList.h"

void BFS_adjList(graphType2* g, int v);
