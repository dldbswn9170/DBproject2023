void merge(int a[], int m, int middle, int n);
void mergeSort(int a[], int m, int n);
